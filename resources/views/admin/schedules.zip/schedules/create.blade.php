@extends('layouts.admin')
@section('content')
<h4>Create Schedule</h4>
<div class="card">
    <div class="card-body">
    </div>
</div>



@endsection
@section('scripts')
@parent
<script>
    
</script>
@endsection